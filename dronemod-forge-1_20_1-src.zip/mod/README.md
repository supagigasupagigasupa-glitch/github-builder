# Drone Mod - Forge 1.20.1 (source project)

Drones, cars and transforming mechas you can **ride or remote-control**, link to a **computer**, and **fuse** together.
This is the Java Edition rewrite of the Bedrock add-on: real riding instead of command hacks, a real radial
GUI, a real computer screen, GeckoLib models/animations with glowing parts, and new mechanics.

> **Status: written but NOT compiled or run.** The environment this was produced in has no Forge, Gradle or GeckoLib
> download access, so nothing here has been built or play-tested. Expect to fix a few small compile errors on the first build
> (see "If the build fails"). Send me the compiler output and I'll fix them.

## Build the .jar (pick one)

The jar has to be compiled against Forge, Minecraft and GeckoLib, so it can only be built on a machine with internet.

**A. Windows:** install **JDK 17** (e.g. Temurin 17), double-click `build.bat`.
**B. Linux / macOS:** install JDK 17, run `./build.sh`.
Both download Gradle 8.1.1 themselves (no Gradle install needed). The jar appears in `build/libs/dronemod-1.0.0.jar`.

**C. Phone only, no PC (GitHub):**
1. Make a free GitHub repository (github.com in your phone browser).
2. *Add file -> Upload files*: upload `dronemod-forge-1.20.1-src.zip` (you do not need to unzip it).
3. *Add file -> Create new file*, name it `.github/workflows/build.yml` and paste the contents of `build.yml` (it is next to this zip).
4. Open the **Actions** tab -> *Build mod jar* -> *Run workflow*. After a few minutes download the **dronemod-jar** artifact:
   it is a zip containing `dronemod-1.0.0.jar` - that jar is the mod.

Install: Minecraft **1.20.1** + **Forge 47.x** + **GeckoLib 4.8.5 (1.20.1)** - put the Forge jar installer result, GeckoLib and `dronemod-1.0.0.jar` in `mods/`.
GeckoLib 4.8.5 is bundled in `libs/` (it is the same jar you must put in your `mods` folder), so no extra download is needed for it.

## Textures
All model textures are painted procedurally at high resolution (512 - 1024 px): metallic paint with clear-coat gloss, bevels,
panel seams and rivets, scratches, brushed gun-metal, chrome bands, reflective glass, tyre tread and bloomed emissive lights
(each model also has a `_glowmask.png` so lights, visors and cores glow in the dark).

## What's in it

| Item / block | What it does |
|---|---|
| **Drone Remote** (3D model) | Right-click a vehicle: get in. Sneak + right-click: remote-control it through its camera. Right-click in the air: disconnect. |
| **Computer** (block, 3D model) | Opens **DroneOS**: one file per linked vehicle (max 8), status, position, health, **Play** (remote control) and **Unlink**. |
| **Drone Link Tool** | Use on a vehicle to select it, then on a Computer to link it. |
| **Fusioner** | Place two transformable mechas near you (any form), right-click: 5-second cinematic fusion into the **Fusion Titan**. |
| Vehicles | Drone, Red Car, Mini/Giant Transformable Drone, Mini/Giant Transformable Car, **Red Silver Mecha** (mecha / car / dino / helicopter / plane), Fusion Titan. |

### Controls (rebindable under *Drone Mod*)
- **W A S D** move, **Space** up / jump, **Left Ctrl** down / brake, **Sprint** boost, **Shift** get out (when riding)
- **R** transform: two-form vehicles toggle, the Red Silver Mecha opens the **radial menu**
  (mouse to a tile - Mecha centre, Plane up, Car down, Dino left, Helicopter right - then click)
- **V** smash (mecha / dino): area damage + knockback
- **X** disconnect remote control

### Mechanics
- Server-authoritative physics: cars accelerate, steer and brake; helicopters/drones hover; planes always fly forward;
  mechas and the dino walk, jump and step up blocks; cars hurt what they run over; boost; fall damage is cancelled.
- Transformations take 3 s (animated), change hitbox and movement mode; the Red Silver Mecha changes shape *through* the mecha.
- Iron ingot on a vehicle repairs it. Destroyed vehicles drop their item.
- Piloting HUD (speed / health blocks / form / hints), glow-in-the-dark lights, visors and cores (GeckoLib glow layer).

## Layout
- `entity/`  `VehicleType` (all stats in one place), `Form`, `Mode`, `VehicleEntity` (movement, transforms, GeckoLib controllers)
- `control/` pilot input state; `network/` packets; `fusion/` server cutscene logic
- `client/`  renderer, key bindings, HUD, radial menu, computer screen, remote camera, fusion camera (`FusionClient`)
- `resources/assets/dronemod/geo|animations|textures|models` - models are Bedrock `.geo.json` files used by GeckoLib

## If the build fails
Things I could not verify against the real 1.20.1 mappings, most likely culprits first:
1. `Entity#onGround()` and `Entity#setMaxUpStep(float)` in `VehicleEntity` (one helper `grounded()` wraps the first).
2. GeckoLib calls were verified against the real 4.8.5 jar (all signatures match); only the Minecraft/Forge calls remain unverified.
3. `HorizontalDirectionalBlock.FACING` / `BaseEntityBlock` details.

## Tuning without recompiling code logic
- Speeds, hitboxes, seat heights, health: `entity/VehicleType.java`.
- Hand position of the 3D remote: `assets/dronemod/models/item/remote.json` -> `display`.
- Animations/timings: `assets/dronemod/animations/*.animation.json` (3 s transform = `VehicleEntity.TRANSFORM_TICKS = 60`).
