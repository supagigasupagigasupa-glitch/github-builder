@echo off
rem Builds build\libs\dronemod-1.0.0.jar. Needs JDK 17 and internet. No Gradle install needed.
cd /d "%~dp0"
java -version 2>&1 | findstr /C:"17." >nul || echo WARNING: ForgeGradle 6 needs JDK 17. Set JAVA_HOME to a JDK 17 if the build fails.
if not exist .gradle-dist\gradle-8.1.1\bin\gradle.bat (
  mkdir .gradle-dist 2>nul
  echo Downloading Gradle 8.1.1...
  powershell -NoProfile -Command "Invoke-WebRequest https://services.gradle.org/distributions/gradle-8.1.1-bin.zip -OutFile .gradle-dist\gradle.zip; Expand-Archive .gradle-dist\gradle.zip -DestinationPath .gradle-dist -Force"
)
call .gradle-dist\gradle-8.1.1\bin\gradle.bat build
echo.
echo DONE - the jar is in build\libs
dir build\libs
pause
