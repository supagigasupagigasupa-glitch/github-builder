package com.dronemod.block;

import com.dronemod.entity.VehicleEntity;
import com.dronemod.registry.ModBlockEntities;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** remembers the vehicles linked to this computer (max 8) */
public class ComputerBlockEntity extends BlockEntity {
    public static final int MAX_LINKS = 8;

    public record Link(UUID id, String type) { }

    private final List<Link> links = new ArrayList<>();

    public ComputerBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.COMPUTER.get(), pos, state);
    }

    public int linkCount() { return links.size(); }

    /** @return 0 linked, 1 already linked, 2 full */
    public int link(UUID id, String type) {
        for (Link l : links) if (l.id().equals(id)) return 1;
        if (links.size() >= MAX_LINKS) return 2;
        links.add(new Link(id, type));
        setChanged();
        return 0;
    }

    public void unlink(int index) {
        if (index >= 0 && index < links.size()) {
            links.remove(index);
            setChanged();
        }
    }

    @Nullable
    public VehicleEntity findVehicle(MinecraftServer server, int index) {
        if (index < 0 || index >= links.size()) return null;
        UUID id = links.get(index).id();
        for (ServerLevel lvl : server.getAllLevels()) {
            Entity e = lvl.getEntity(id);
            if (e instanceof VehicleEntity v && v.isAlive()) return v;
        }
        return null;
    }

    public List<ComputerMenu.Entry> buildEntries(MinecraftServer server) {
        List<ComputerMenu.Entry> out = new ArrayList<>();
        for (int i = 0; i < links.size(); i++) {
            Link l = links.get(i);
            VehicleEntity v = findVehicle(server, i);
            if (v == null) out.add(new ComputerMenu.Entry(l.id(), l.type(), false, 0, 0, 0, 0, false));
            else out.add(new ComputerMenu.Entry(l.id(), l.type(), true, (int) v.getHealth(), (int) v.getX(), (int) v.getY(), (int) v.getZ(),
                    v.isRemoteControlled() || !v.getPassengers().isEmpty()));
        }
        return out;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        ListTag list = new ListTag();
        for (Link l : links) {
            CompoundTag t = new CompoundTag();
            t.putUUID("Id", l.id());
            t.putString("Type", l.type());
            list.add(t);
        }
        tag.put("Links", list);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        links.clear();
        ListTag list = tag.getList("Links", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            links.add(new Link(t.getUUID("Id"), t.getString("Type")));
        }
    }
}
