package com.dronemod.block;

import com.dronemod.registry.ModMenus;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;

/** slot-less menu: just carries the list of linked vehicles to the client */
public class ComputerMenu extends AbstractContainerMenu {
    public record Entry(UUID id, String type, boolean online, int health, int x, int y, int z, boolean busy) { }

    public final BlockPos pos;
    public final List<Entry> entries;

    public ComputerMenu(int id, Inventory inv, BlockPos pos, List<Entry> entries) {
        super(ModMenus.COMPUTER.get(), id);
        this.pos = pos;
        this.entries = entries;
    }

    public ComputerMenu(int id, Inventory inv, FriendlyByteBuf buf) {
        this(id, inv, buf.readBlockPos(), read(buf));
    }

    public static void write(FriendlyByteBuf buf, BlockPos pos, List<Entry> list) {
        buf.writeBlockPos(pos);
        buf.writeVarInt(list.size());
        for (Entry e : list) {
            buf.writeUUID(e.id()).writeUtf(e.type()).writeBoolean(e.online()).writeVarInt(e.health());
            buf.writeVarInt(e.x()).writeVarInt(e.y()).writeVarInt(e.z()).writeBoolean(e.busy());
        }
    }

    private static List<Entry> read(FriendlyByteBuf buf) {
        int n = buf.readVarInt();
        List<Entry> list = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            list.add(new Entry(buf.readUUID(), buf.readUtf(), buf.readBoolean(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readBoolean()));
        }
        return list;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) { return ItemStack.EMPTY; }

    @Override
    public boolean stillValid(Player player) {
        return player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) < 100;
    }
}
