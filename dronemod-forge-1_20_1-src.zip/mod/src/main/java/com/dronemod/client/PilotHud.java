package com.dronemod.client;

import com.dronemod.entity.Form;
import com.dronemod.entity.Mode;
import com.dronemod.entity.VehicleEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/** blocky pilot panel: speed, altitude, form and health of the vehicle you control */
public class PilotHud {
    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui || FusionClient.active()) return;
        VehicleEntity v = ClientState.currentVehicle(mc);
        if (v == null) return;
        Font font = mc.font;
        int bw = 168, bh = 76, x = 10, y = h - bh - 36;

        // panel: dark body, light top-left edge, dark bottom-right edge (like a Minecraft slot)
        g.fill(x - 2, y - 2, x + bw + 2, y + bh + 2, 0xFF000000);
        g.fill(x, y, x + bw, y + bh, 0xD0141A24);
        g.fill(x, y, x + bw, y + 2, 0xFF4A5A7A);
        g.fill(x, y, x + 2, y + bh, 0xFF4A5A7A);
        g.fill(x, y + bh - 2, x + bw, y + bh, 0xFF0A0E14);
        g.fill(x + bw - 2, y, x + bw, y + bh, 0xFF0A0E14);
        g.fill(x, y, x + bw, y + 14, 0xFF2A3B6B);

        Component name = Component.translatable("entity.dronemod." + v.getVehicleType().id);
        g.drawString(font, name, x + 5, y + 3, 0xFFFFFFFF, true);
        if (ClientState.remote) g.drawString(font, Component.translatable("gui.dronemod.hud.remote"), x + bw - 4 - font.width(Component.translatable("gui.dronemod.hud.remote")), y + 3, 0xFFFFD84A, true);

        Form f = v.isTransitioning() ? v.transitionTo() : v.getForm();
        Component formName = Component.translatable("form.dronemod." + f.id);
        g.drawString(font, Component.translatable("gui.dronemod.hud.form", formName), x + 6, y + 18, 0xFFC6C6C6, true);

        // speed bar: 12 blocks
        float maxSp = v.getVehicleType().speed(v.getForm()) * 20f * 1.5f;
        int filled = Math.min(12, Math.round(12f * v.getSpeedBlocksPerSecond() / Math.max(1f, maxSp)));
        g.drawString(font, Component.translatable("gui.dronemod.hud.speed", String.format("%.1f", v.getSpeedBlocksPerSecond())), x + 6, y + 30, 0xFFC6C6C6, true);
        for (int i = 0; i < 12; i++) g.fill(x + 6 + i * 13, y + 42, x + 6 + i * 13 + 11, y + 48, i < filled ? 0xFF55FF55 : 0xFF2B3340);

        // health bar: 12 blocks
        int hp = Math.round(12f * v.getHealth() / Math.max(1f, v.getMaxHealth()));
        for (int i = 0; i < 12; i++) g.fill(x + 6 + i * 13, y + 52, x + 6 + i * 13 + 11, y + 58, i < hp ? 0xFFFF4040 : 0xFF2B3340);

        String alt = String.format("%.0f", v.getY());
        g.drawString(font, Component.translatable("gui.dronemod.hud.alt", alt), x + 6, y + 63, 0xFF9AA8C0, true);

        Mode m = v.getVehicleType().mode(v.getForm());
        Component hint = m == Mode.WALK
                ? Component.translatable("gui.dronemod.hud.hint_walk", ModKeys.SMASH.getTranslatedKeyMessage(), ModKeys.TRANSFORM.getTranslatedKeyMessage())
                : Component.translatable("gui.dronemod.hud.hint", ModKeys.TRANSFORM.getTranslatedKeyMessage());
        g.drawString(font, hint, x + 62, y + 63, 0xFF9AA8C0, true);
    }
}
