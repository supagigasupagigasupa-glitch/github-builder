package com.dronemod.client.render;

import com.dronemod.entity.VehicleEntity;
import com.dronemod.entity.VehicleType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

public class VehicleRenderer extends GeoEntityRenderer<VehicleEntity> {
    public VehicleRenderer(EntityRendererProvider.Context ctx, VehicleType type) {
        super(ctx, new VehicleModel());
        this.shadowRadius = 0.7f * type.scale;
        withScale(type.scale);
        // lights, visors, reactor cores... glow in the dark (textures/entity/<model>_glowmask.png)
        addRenderLayer(new AutoGlowingGeoLayer<>(this));
    }
}
