package com.dronemod.client.screen;

import com.dronemod.DroneMod;
import com.dronemod.block.ComputerMenu;
import com.dronemod.network.ComputerActionPacket;
import com.dronemod.network.ModNetwork;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

/** "DroneOS": one file per linked vehicle; pick a file, then Play (remote control) or Unlink */
public class ComputerScreen extends AbstractContainerScreen<ComputerMenu> {
    private static final int COLS = 2, TILE_W = 64, TILE_H = 38;

    private int selected = -1;
    private Button play, unlink;

    public ComputerScreen(ComputerMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 256;
        this.imageHeight = 184;
    }

    @Override
    protected void init() {
        super.init();
        play = addRenderableWidget(Button.builder(Component.translatable("gui.dronemod.play"), b -> act(ComputerActionPacket.PLAY))
                .bounds(leftPos + 150, topPos + 134, 98, 20).build());
        unlink = addRenderableWidget(Button.builder(Component.translatable("gui.dronemod.unlink"), b -> act(ComputerActionPacket.UNLINK))
                .bounds(leftPos + 150, topPos + 158, 98, 20).build());
        refreshButtons();
    }

    private void refreshButtons() {
        boolean has = selected >= 0 && selected < menu.entries.size();
        ComputerMenu.Entry e = has ? menu.entries.get(selected) : null;
        play.active = has && e.online() && !e.busy();
        unlink.active = has;
    }

    private void act(int action) {
        if (selected < 0 || selected >= menu.entries.size()) return;
        ModNetwork.CH.sendToServer(new ComputerActionPacket(menu.pos, action, selected));
        onClose();
    }

    private int tileX(int i) { return leftPos + 10 + (i % COLS) * (TILE_W + 6); }
    private int tileY(int i) { return topPos + 30 + (i / COLS) * (TILE_H + 6); }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (int i = 0; i < menu.entries.size(); i++) {
            int x = tileX(i), y = tileY(i);
            if (mx >= x && mx < x + TILE_W && my >= y && my < y + TILE_H) {
                selected = i;
                refreshButtons();
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        super.render(g, mx, my, pt);
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mx, int my) { }

    private void bevel(GuiGraphics g, int x, int y, int w, int h, int body, boolean pressed) {
        g.fill(x, y, x + w, y + h, body);
        g.fill(x, y, x + w, y + 2, pressed ? 0xFF373737 : 0xFFFFFFFF);
        g.fill(x, y, x + 2, y + h, pressed ? 0xFF373737 : 0xFFFFFFFF);
        g.fill(x, y + h - 2, x + w, y + h, pressed ? 0xFFFFFFFF : 0xFF373737);
        g.fill(x + w - 2, y, x + w, y + h, pressed ? 0xFFFFFFFF : 0xFF373737);
    }

    @Override
    protected void renderBg(GuiGraphics g, float pt, int mx, int my) {
        int x = leftPos, y = topPos, w = imageWidth, h = imageHeight;
        g.fill(x - 3, y - 3, x + w + 3, y + h + 3, 0xFF000000);
        bevel(g, x, y, w, h, 0xFFC6C6C6, false);
        g.fill(x + 4, y + 4, x + w - 4, y + 22, 0xFF2A3B6B);
        g.drawString(font, Component.translatable("gui.dronemod.computer.title"), x + 10, y + 9, 0xFFFFFFFF, true);

        // desktop area
        g.fill(x + 8, y + 26, x + 144, y + h - 8, 0xFF1E2A44);
        g.fill(x + 146, y + 26, x + w - 8, y + h - 8, 0xFF8B8B8B);
        if (menu.entries.isEmpty()) {
            g.drawString(font, Component.translatable("gui.dronemod.computer.empty"), x + 14, y + 36, 0xFFB0B8C8, false);
            g.drawString(font, Component.translatable("gui.dronemod.computer.empty2"), x + 14, y + 48, 0xFF7C86A0, false);
        }
        for (int i = 0; i < menu.entries.size(); i++) {
            ComputerMenu.Entry e = menu.entries.get(i);
            int tx = tileX(i), ty = tileY(i);
            boolean sel = i == selected;
            g.fill(tx - 2, ty - 2, tx + TILE_W + 2, ty + TILE_H + 2, sel ? 0xFFFFD84A : 0xFF0C1220);
            bevel(g, tx, ty, TILE_W, TILE_H, sel ? 0xFF4A5E8C : 0xFF34466E, false);
            g.blit(new ResourceLocation(DroneMod.MODID, "textures/item/" + e.type() + ".png"), tx + 4, ty + 5, 24, 24, 0, 0, 32, 32, 32, 32);
            g.drawString(font, Component.translatable("gui.dronemod.computer.file", i + 1), tx + 31, ty + 7, 0xFFFFFFFF, false);
            g.fill(tx + 31, ty + 20, tx + 37, ty + 26, e.online() ? (e.busy() ? 0xFFFFB030 : 0xFF55FF55) : 0xFFFF5555);
            g.drawString(font, Component.translatable(e.online() ? (e.busy() ? "gui.dronemod.status.busy" : "gui.dronemod.status.ready") : "gui.dronemod.status.offline"),
                    tx + 40, ty + 19, 0xFFD0D8E8, false);
        }

        // details of the selected file
        if (selected >= 0 && selected < menu.entries.size()) {
            ComputerMenu.Entry e = menu.entries.get(selected);
            g.drawString(font, Component.translatable("entity.dronemod." + e.type()), x + 152, y + 32, 0xFF202020, false);
            if (e.online()) {
                g.drawString(font, Component.translatable("gui.dronemod.computer.pos", e.x(), e.y(), e.z()), x + 152, y + 48, 0xFF303030, false);
                g.drawString(font, Component.translatable("gui.dronemod.computer.health", e.health()), x + 152, y + 62, 0xFF303030, false);
                for (int i = 0; i < 10; i++) g.fill(x + 152 + i * 9, y + 78, x + 152 + i * 9 + 7, y + 84, i < Math.min(10, e.health() / 10 + 1) ? 0xFFE03030 : 0xFF404040);
            } else {
                g.drawString(font, Component.translatable("gui.dronemod.computer.offline"), x + 152, y + 48, 0xFF8A1010, false);
            }
        } else {
            g.drawString(font, Component.translatable("gui.dronemod.computer.select"), x + 152, y + 32, 0xFF404040, false);
        }
    }
}
