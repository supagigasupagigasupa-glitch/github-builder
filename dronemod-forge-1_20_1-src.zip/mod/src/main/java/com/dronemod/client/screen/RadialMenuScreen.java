package com.dronemod.client.screen;

import com.dronemod.DroneMod;
import com.dronemod.client.ModKeys;
import com.dronemod.entity.Form;
import com.dronemod.entity.VehicleEntity;
import com.dronemod.network.ActionPacket;
import com.dronemod.network.ModNetwork;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import org.lwjgl.glfw.GLFW;

/**
 * Blocky radial form picker: Mecha in the middle, Plane above, Car below, Dino left, Helicopter right.
 * Move the mouse towards a tile, click (or press Enter / the transform key) to confirm.
 */
public class RadialMenuScreen extends Screen {
    private static final int TILE = 48;
    private static final int RING = 80;

    private final VehicleEntity vehicle;
    private Form selected;

    public RadialMenuScreen(VehicleEntity vehicle) {
        super(Component.translatable("gui.dronemod.radial"));
        this.vehicle = vehicle;
        this.selected = vehicle.getForm();
    }

    @Override
    public boolean isPauseScreen() { return false; }

    private int offX(Form f) { return f == Form.HELI ? RING : f == Form.DINO ? -RING : 0; }
    private int offY(Form f) { return f == Form.CAR ? RING : f == Form.PLANE ? -RING : 0; }

    private Form hover(double mx, double my) {
        double dx = mx - width / 2.0, dy = my - height / 2.0;
        if (Math.hypot(dx, dy) < TILE * 0.75) return Form.MECHA;
        if (Math.abs(dx) > Math.abs(dy)) return dx > 0 ? Form.HELI : Form.DINO;
        return dy > 0 ? Form.CAR : Form.PLANE;
    }

    private void bevel(GuiGraphics g, int x, int y, int w, int h, int body) {
        g.fill(x, y, x + w, y + h, body);
        g.fill(x, y, x + w, y + 2, 0xFFFFFFFF);
        g.fill(x, y, x + 2, y + h, 0xFFFFFFFF);
        g.fill(x, y + h - 2, x + w, y + h, 0xFF373737);
        g.fill(x + w - 2, y, x + w, y + h, 0xFF373737);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(0, 0, width, height, 0x70000000);
        selected = hover(mx, my);
        int cx = width / 2, cy = height / 2;

        // cross-shaped plate behind the tiles
        int arm = RING + TILE / 2 + 8, half = TILE / 2 + 8;
        g.fill(cx - arm - 2, cy - half - 2, cx + arm + 2, cy + half + 2, 0xFF101010);
        g.fill(cx - half - 2, cy - arm - 2, cx + half + 2, cy + arm + 2, 0xFF101010);
        g.fill(cx - arm, cy - half, cx + arm, cy + half, 0xE0262B36);
        g.fill(cx - half, cy - arm, cx + half, cy + arm, 0xE0262B36);

        for (Form f : new Form[] { Form.PLANE, Form.DINO, Form.HELI, Form.CAR, Form.MECHA }) {
            int x = cx + offX(f) - TILE / 2, y = cy + offY(f) - TILE / 2;
            boolean sel = f == selected, cur = f == vehicle.getForm();
            int s = sel ? 4 : 0;
            g.fill(x - 3 - s, y - 3 - s, x + TILE + 3 + s, y + TILE + 3 + s, sel ? 0xFFFFD84A : cur ? 0xFF55FF55 : 0xFF1A1A1A);
            bevel(g, x - s, y - s, TILE + 2 * s, TILE + 2 * s, 0xFF8B8B8B);
            ResourceLocation icon = new ResourceLocation(DroneMod.MODID, "textures/gui/forms/" + f.id + ".png");
            g.blit(icon, x + 6 - s, y + 6 - s, TILE - 12 + 2 * s, TILE - 12 + 2 * s, 0, 0, 32, 32, 32, 32);
            Component label = Component.translatable("form.dronemod." + f.id);
            g.drawCenteredString(font, label, cx + offX(f), y + TILE + 6 + s, sel ? 0xFFFFD84A : cur ? 0xFF55FF55 : 0xFFFFFFFF);
        }
        g.drawCenteredString(font, Component.translatable("gui.dronemod.radial.hint"), cx, cy + arm + 10, 0xFFA0A0A0);
        super.render(g, mx, my, pt);
    }

    private void confirm() {
        if (selected != vehicle.getForm() && !vehicle.isTransitioning()) {
            ModNetwork.CH.sendToServer(new ActionPacket(ActionPacket.FORM, selected.ordinal()));
        }
        onClose();
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        confirm();
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ENTER || ModKeys.TRANSFORM.matches(key, scan)) {
            confirm();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }
}
