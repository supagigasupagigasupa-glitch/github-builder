package com.dronemod.control;

/** What a pilot is pressing, sent from the client every tick. */
public class ControlState {
    public float forward, strafe, yaw, pitch;
    public boolean up, down, boost;
    public long tick;

    public ControlState copy() {
        ControlState c = new ControlState();
        c.forward = forward; c.strafe = strafe; c.yaw = yaw; c.pitch = pitch;
        c.up = up; c.down = down; c.boost = boost; c.tick = tick;
        return c;
    }

    /** same look direction but no buttons held (used when packets stop arriving) */
    public ControlState released() {
        ControlState c = new ControlState();
        c.yaw = yaw; c.pitch = pitch; c.tick = tick;
        return c;
    }
}
