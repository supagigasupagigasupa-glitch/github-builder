package com.dronemod.entity;

/** The shapes a vehicle can take. VEHICLE is the "base" vehicle of two-form types (drone or car). */
public enum Form {
    MECHA("mecha"), VEHICLE("vehicle"), CAR("car"), DINO("dino"), HELI("heli"), PLANE("plane");

    public final String id;

    Form(String id) { this.id = id; }

    public static Form byOrdinal(int i) {
        Form[] v = values();
        return i >= 0 && i < v.length ? v[i] : MECHA;
    }
}
