package com.dronemod.entity;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EntityDimensions;

public enum VehicleType {
    DRONE("drone", "drone", 1.0f, 30, Form.VEHICLE, false),
    CAR("car", "car", 1.0f, 50, Form.VEHICLE, false),
    MINI_TRANSFORMER("mini_transformer", "giant_drone", 1.0f, 60, Form.VEHICLE, true),
    GIANT_DRONE("giant_drone", "giant_drone", 3.0f, 160, Form.VEHICLE, true),
    MINI_CAR("mini_car", "carbot", 1.0f, 70, Form.VEHICLE, true),
    GIANT_CAR("giant_car", "carbot", 3.0f, 180, Form.VEHICLE, true),
    RED_SILVER("red_silver", "red_silver", 2.0f, 240, Form.MECHA, true),
    FUSION_TITAN("fusion_titan", "fusion_titan", 3.5f, 500, Form.MECHA, false);

    public final String id;
    /** name of the geo / animation / texture files (several vehicles share one model) */
    public final String model;
    public final float scale;
    public final int health;
    public final Form defaultForm;
    /** can switch between forms (and be used with the Fusioner) */
    public final boolean transformable;

    VehicleType(String id, String model, float scale, int health, Form defaultForm, boolean transformable) {
        this.id = id;
        this.model = model;
        this.scale = scale;
        this.health = health;
        this.defaultForm = defaultForm;
        this.transformable = transformable;
    }

    public boolean multiForm() { return this == RED_SILVER; }

    public boolean flyerVehicle() { return this == DRONE || this == MINI_TRANSFORMER || this == GIANT_DRONE; }

    public List<Form> forms() {
        if (this == RED_SILVER) return List.of(Form.MECHA, Form.CAR, Form.DINO, Form.HELI, Form.PLANE);
        if (this == FUSION_TITAN) return List.of(Form.MECHA);
        if (transformable) return List.of(Form.VEHICLE, Form.MECHA);
        return List.of(Form.VEHICLE);
    }

    public boolean allows(Form f) { return forms().contains(f); }

    public Mode mode(Form f) {
        switch (f) {
            case VEHICLE: return flyerVehicle() ? Mode.HOVER : Mode.GROUND_CAR;
            case CAR: return Mode.GROUND_CAR;
            case HELI: return Mode.HOVER;
            case PLANE: return Mode.PLANE;
            default: return Mode.WALK;
        }
    }

    /** top speed in blocks per tick */
    public float speed(Form f) {
        switch (mode(f)) {
            case HOVER: return this == RED_SILVER ? 0.6f : this == GIANT_DRONE ? 0.7f : this == MINI_TRANSFORMER ? 0.55f : 0.5f;
            case GROUND_CAR: return this == GIANT_CAR ? 0.9f : this == RED_SILVER ? 0.75f : 0.6f;
            case PLANE: return 1.0f;
            default:
                if (f == Form.DINO) return 0.4f;
                if (this == FUSION_TITAN) return 0.32f;
                if (this == GIANT_DRONE || this == GIANT_CAR) return 0.3f;
                return this == RED_SILVER ? 0.27f : 0.24f;
        }
    }

    private static EntityDimensions d(float w, float h) { return EntityDimensions.scalable(w, h); }

    public EntityDimensions dimensions(Form f) {
        switch (this) {
            case DRONE: return d(1.4f, 0.6f);
            case CAR: return d(1.4f, 0.9f);
            case MINI_TRANSFORMER: return f == Form.MECHA ? d(1.0f, 2.2f) : d(1.6f, 0.6f);
            case GIANT_DRONE: return f == Form.MECHA ? d(2.8f, 6.4f) : d(4.0f, 1.4f);
            case MINI_CAR: return f == Form.MECHA ? d(1.0f, 2.2f) : d(1.4f, 0.9f);
            case GIANT_CAR: return f == Form.MECHA ? d(2.8f, 6.4f) : d(4.0f, 2.4f);
            case RED_SILVER:
                switch (f) {
                    case CAR: return d(2.9f, 2.0f);
                    case DINO: return d(2.2f, 2.9f);
                    case HELI: return d(2.4f, 2.3f);
                    case PLANE: return d(3.0f, 2.5f);
                    default: return d(2.2f, 4.2f);
                }
            default: return d(3.6f, 7.4f);
        }
    }

    /** where the rider sits (blocks above the vehicle's feet) */
    public float seatHeight(Form f) {
        float h = dimensions(f).height;
        return (f == Form.MECHA || f == Form.DINO) ? h * 0.62f : h * 0.38f;
    }

    public float eyeHeight(Form f) { return dimensions(f).height * 0.85f; }

    public static VehicleType byId(String id) {
        for (VehicleType t : values()) if (t.id.equals(id)) return t;
        return DRONE;
    }
}
