package com.dronemod.item;

import com.dronemod.block.ComputerBlockEntity;
import com.dronemod.entity.VehicleEntity;
import com.dronemod.entity.VehicleType;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;

/** Use on a vehicle to select it, then on a computer to link it. A computer holds up to 8 vehicles. */
public class LinkToolItem extends Item {
    public LinkToolItem(Properties props) { super(props); }

    public static void select(Player player, ItemStack stack, VehicleEntity v) {
        CompoundTag tag = stack.getOrCreateTag();
        tag.putUUID("Selected", v.getUUID());
        tag.putString("SelectedType", v.getVehicleType().id);
        player.displayClientMessage(Component.translatable("message.dronemod.selected", Component.translatable("entity.dronemod." + v.getVehicleType().id)), true);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        BlockEntity be = level.getBlockEntity(ctx.getClickedPos());
        if (!(be instanceof ComputerBlockEntity pc)) return InteractionResult.PASS;
        Player player = ctx.getPlayer();
        if (level.isClientSide || player == null) return InteractionResult.SUCCESS;
        CompoundTag tag = ctx.getItemInHand().getOrCreateTag();
        if (!tag.hasUUID("Selected")) {
            player.displayClientMessage(Component.translatable("message.dronemod.select_first"), true);
            return InteractionResult.CONSUME;
        }
        UUID id = tag.getUUID("Selected");
        VehicleType type = VehicleType.byId(tag.getString("SelectedType"));
        switch (pc.link(id, type.id)) {
            case 0 -> player.displayClientMessage(Component.translatable("message.dronemod.linked", Component.translatable("entity.dronemod." + type.id), pc.linkCount(), ComputerBlockEntity.MAX_LINKS), true);
            case 1 -> player.displayClientMessage(Component.translatable("message.dronemod.already_linked"), true);
            default -> player.displayClientMessage(Component.translatable("message.dronemod.full"), true);
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.dronemod.link.1"));
        CompoundTag tag = stack.getTag();
        if (tag != null && tag.contains("SelectedType")) {
            tooltip.add(Component.translatable("tooltip.dronemod.link.selected", Component.translatable("entity.dronemod." + tag.getString("SelectedType"))));
        }
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag != null && tag.hasUUID("Selected");
    }
}
