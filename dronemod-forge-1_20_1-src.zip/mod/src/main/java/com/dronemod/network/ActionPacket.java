package com.dronemod.network;

import com.dronemod.control.ControlManager;
import com.dronemod.entity.Form;
import com.dronemod.entity.VehicleEntity;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** client -> server: one-shot actions of the pilot */
public class ActionPacket {
    public static final int FORM = 0;       // arg = Form ordinal (multi-form vehicles)
    public static final int TOGGLE = 1;     // two-form vehicles
    public static final int SMASH = 2;
    public static final int EXIT_REMOTE = 3;

    private final int action;
    private final int arg;

    public ActionPacket(int action, int arg) { this.action = action; this.arg = arg; }

    public static void encode(ActionPacket m, FriendlyByteBuf buf) { buf.writeVarInt(m.action).writeVarInt(m.arg); }

    public static ActionPacket decode(FriendlyByteBuf buf) { return new ActionPacket(buf.readVarInt(), buf.readVarInt()); }

    public static void handle(ActionPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer p = c.getSender();
            if (p == null) return;
            VehicleEntity v = ControlManager.vehicleOf(p);
            if (v == null) return;
            switch (m.action) {
                case FORM -> v.requestForm(Form.byOrdinal(m.arg));
                case TOGGLE -> v.toggleForm();
                case SMASH -> v.smash(p);
                case EXIT_REMOTE -> { if (v.isRemoteControlled()) v.stopRemote(p); }
                default -> { }
            }
        });
        c.setPacketHandled(true);
    }
}
