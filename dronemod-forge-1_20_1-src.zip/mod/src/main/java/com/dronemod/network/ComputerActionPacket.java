package com.dronemod.network;

import com.dronemod.block.ComputerBlockEntity;
import com.dronemod.entity.VehicleEntity;
import java.util.function.Supplier;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.network.NetworkEvent;

/** client -> server: buttons of the computer screen */
public class ComputerActionPacket {
    public static final int PLAY = 0;
    public static final int UNLINK = 1;

    private final BlockPos pos;
    private final int action;
    private final int index;

    public ComputerActionPacket(BlockPos pos, int action, int index) { this.pos = pos; this.action = action; this.index = index; }

    public static void encode(ComputerActionPacket m, FriendlyByteBuf buf) { buf.writeBlockPos(m.pos).writeVarInt(m.action).writeVarInt(m.index); }

    public static ComputerActionPacket decode(FriendlyByteBuf buf) { return new ComputerActionPacket(buf.readBlockPos(), buf.readVarInt(), buf.readVarInt()); }

    public static void handle(ComputerActionPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer p = c.getSender();
            if (p == null || p.distanceToSqr(m.pos.getX() + 0.5, m.pos.getY() + 0.5, m.pos.getZ() + 0.5) > 100) return;
            BlockEntity be = p.level().getBlockEntity(m.pos);
            if (!(be instanceof ComputerBlockEntity pc)) return;
            if (m.action == UNLINK) { pc.unlink(m.index); return; }
            VehicleEntity v = pc.findVehicle(p.getServer(), m.index);
            if (v == null) { p.displayClientMessage(Component.translatable("message.dronemod.not_found"), true); return; }
            if (v.isRemoteControlled() || !v.getPassengers().isEmpty()) { p.displayClientMessage(Component.translatable("message.dronemod.in_use"), true); return; }
            v.startRemote(p);
        });
        c.setPacketHandled(true);
    }
}
