package com.dronemod.network;

import com.dronemod.DroneMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class ModNetwork {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(DroneMod.MODID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private static int id = 0;

    public static void register() {
        CH.registerMessage(id++, ControlPacket.class, ControlPacket::encode, ControlPacket::decode, ControlPacket::handle);
        CH.registerMessage(id++, ActionPacket.class, ActionPacket::encode, ActionPacket::decode, ActionPacket::handle);
        CH.registerMessage(id++, ComputerActionPacket.class, ComputerActionPacket::encode, ComputerActionPacket::decode, ComputerActionPacket::handle);
        CH.registerMessage(id++, RemoteModePacket.class, RemoteModePacket::encode, RemoteModePacket::decode, RemoteModePacket::handle);
        CH.registerMessage(id++, FusionPacket.class, FusionPacket::encode, FusionPacket::decode, FusionPacket::handle);
    }
}
