package com.dronemod.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** server -> client: start / stop viewing a vehicle through its camera */
public class RemoteModePacket {
    private final boolean start;
    private final int entityId;

    public RemoteModePacket(boolean start, int entityId) { this.start = start; this.entityId = entityId; }

    public static void encode(RemoteModePacket m, FriendlyByteBuf buf) { buf.writeBoolean(m.start).writeVarInt(m.entityId); }

    public static RemoteModePacket decode(FriendlyByteBuf buf) { return new RemoteModePacket(buf.readBoolean(), buf.readVarInt()); }

    public static void handle(RemoteModePacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.dronemod.client.ClientHooks.remoteMode(m.start, m.entityId)));
        c.setPacketHandled(true);
    }
}
