package com.dronemod.registry;

import com.dronemod.DroneMod;
import com.dronemod.block.ComputerBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, DroneMod.MODID);

    public static final RegistryObject<BlockEntityType<ComputerBlockEntity>> COMPUTER = BLOCK_ENTITIES.register("computer",
            () -> BlockEntityType.Builder.of(ComputerBlockEntity::new, ModBlocks.COMPUTER.get()).build(null));
}
