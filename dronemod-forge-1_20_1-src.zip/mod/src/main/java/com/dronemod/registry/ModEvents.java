package com.dronemod.registry;

import com.dronemod.DroneMod;
import com.dronemod.entity.VehicleEntity;
import com.dronemod.entity.VehicleType;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = DroneMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEvents {
    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent event) {
        for (VehicleType vt : VehicleType.values()) {
            event.put(ModEntities.get(vt), VehicleEntity.createAttributes().build());
        }
    }
}
