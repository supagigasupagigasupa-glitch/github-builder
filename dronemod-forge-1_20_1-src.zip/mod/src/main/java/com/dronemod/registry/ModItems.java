package com.dronemod.registry;

import com.dronemod.DroneMod;
import com.dronemod.entity.VehicleType;
import com.dronemod.item.FusionerItem;
import com.dronemod.item.LinkToolItem;
import com.dronemod.item.RemoteItem;
import com.dronemod.item.VehicleItem;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, DroneMod.MODID);

    public static final RegistryObject<Item> REMOTE = ITEMS.register("remote", () -> new RemoteItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> LINK_TOOL = ITEMS.register("link_tool", () -> new LinkToolItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> FUSIONER = ITEMS.register("fusioner", () -> new FusionerItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> COMPUTER = ITEMS.register("computer", () -> new BlockItem(ModBlocks.COMPUTER.get(), new Item.Properties()));

    public static final Map<VehicleType, RegistryObject<Item>> VEHICLES = new EnumMap<>(VehicleType.class);

    static {
        for (VehicleType vt : VehicleType.values()) {
            if (vt == VehicleType.FUSION_TITAN) continue;
            VEHICLES.put(vt, ITEMS.register(vt.id, () -> new VehicleItem(new Item.Properties().stacksTo(vt.scale >= 2 ? 4 : 16), vt)));
        }
    }

    /** what a destroyed vehicle drops */
    public static Item dropFor(VehicleType vt) {
        RegistryObject<Item> r = VEHICLES.get(vt);
        return r != null ? r.get() : FUSIONER.get();
    }
}
