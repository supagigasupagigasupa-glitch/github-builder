package com.dronemod.registry;

import com.dronemod.DroneMod;
import com.dronemod.block.ComputerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModMenus {
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(ForgeRegistries.MENU_TYPES, DroneMod.MODID);

    public static final RegistryObject<MenuType<ComputerMenu>> COMPUTER = MENUS.register("computer",
            () -> IForgeMenuType.create(ComputerMenu::new));
}
